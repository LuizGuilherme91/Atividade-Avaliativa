import java.sql.Connection;
import java.sql.Date;

public class ListaTarefas extends ClasseGenerica{
    private Integer id;
    private Date data_tarefa;
    private String descricao_tarefa;
    private String observacao;
    private Responsavel responsavel;
    private Prioridade prioridade;

    public ListaTarefas() {}
    public ListaTarefas(Integer id, Date data_tarefa, String descricao_tarefa, String observacao, Responsavel responsavel, Prioridade prioridade) {
        this.id = id;
        this.data_tarefa = data_tarefa;
        this.descricao_tarefa = descricao_tarefa;
        this.observacao = observacao;
        this.responsavel = responsavel;
        this.prioridade = prioridade;
    }

    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }

    public Date getData_tarefa() {
        return data_tarefa;
    }
    public void setData_tarefa(Date data_tarefa) {
        this.data_tarefa = data_tarefa;
    }

    public String getDescricao_tarefa () {
        return descricao_tarefa;
    }
    public void setDescricao_tarefa (String descricao_tarefa) {
        this.descricao_tarefa = descricao_tarefa;
    }

    public String getObservacao() {
        return observacao;
    }
    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public Responsavel getResponsavel() {
        return responsavel;
    }
    public void setResponsavel(Responsavel responsavel) {
        this.responsavel = responsavel;
    }

    public Prioridade getPrioridade() {
        return prioridade;
    }
    public void setPrioridade(Prioridade prioridade) {
        this.prioridade = prioridade;
    }

    public boolean salvarListaTarefas(ListaTarefas listaTarefas) {
        String sql = "INSERT INTO lista_tarefas (data_tarefa, descricao_tarefa, observacao, responsavel_id, prioridade_id) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = ConexaoBanco.getConnection();          
             java.sql.PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, listaTarefas.getData_tarefa());
            stmt.setString(2, listaTarefas.getDescricao_tarefa());
            stmt.setString(3, listaTarefas.getObservacao());
            stmt.setInt(4, listaTarefas.getResponsavel().getId());
            stmt.setInt(5, listaTarefas.getPrioridade().getId());
            stmt.executeUpdate();
            System.out.println("Lista de tarefas salva com sucesso!");
            return true;
        } catch (java.sql.SQLException e) {
            System.out.println("Erro ao salvar lista de tarefas: " + e.getMessage());
            return false;
        }
    }

    public boolean alterarListaTarefas(ListaTarefas listaTarefas) {
        String sql = "UPDATE lista_tarefas SET data_tarefa = ?, descricao_tarefa = ?, observacao = ?, responsavel_id = ?, prioridade_id = ? WHERE id = ?";
        try (Connection conn = ConexaoBanco.getConnection();
             java.sql.PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, listaTarefas.getData_tarefa());
            stmt.setString(2, listaTarefas.getDescricao_tarefa());
            stmt.setString(3, listaTarefas.getObservacao());
            stmt.setInt(4, listaTarefas.getResponsavel().getId());
            stmt.setInt(5, listaTarefas.getPrioridade().getId());
            stmt.setInt(6, listaTarefas.getId());
            stmt.executeUpdate();
            System.out.println("Lista de tarefas alterada com sucesso!");
            return true;
        } catch (java.sql.SQLException e) {
            System.out.println("Erro ao alterar lista de tarefas: " + e.getMessage());
            return false;
        }
    }

    public boolean deletarListaTarefas(ListaTarefas listaTarefas) {
        String sql = "DELETE FROM lista_tarefas WHERE id = ?";
        try (Connection conn = ConexaoBanco.getConnection();
             java.sql.PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, listaTarefas.getId());
            stmt.executeUpdate();
            System.out.println("Lista de tarefas deletada com sucesso!");
            return true;
        } catch (java.sql.SQLException e) {
            System.out.println("Erro ao deletar lista de tarefas: " + e.getMessage());
            return false;
        }
    }

    public boolean pesquisarListaTarefas(ListaTarefas listaTarefas) {
        String sql = "SELECT * FROM lista_tarefas WHERE id = ?";
        try (Connection conn = ConexaoBanco.getConnection();
             java.sql.PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, listaTarefas.getId());
            var rs = stmt.executeQuery();
            if (rs.next()) {
                listaTarefas.setData_tarefa(rs.getDate("data_tarefa"));
                listaTarefas.setDescricao_tarefa(rs.getString("descricao_tarefa"));
                listaTarefas.setObservacao(rs.getString("observacao"));
                // Buscar responsável e prioridade
                Responsavel responsavel = new Responsavel();
                responsavel.setId(rs.getInt("responsavel_id"));
                listaTarefas.setResponsavel(responsavel);
                Prioridade prioridade = new Prioridade();
                prioridade.setId(rs.getInt("prioridade_id"));
                listaTarefas.setPrioridade(prioridade);
                System.out.println("Lista de tarefas encontrada: " + listaTarefas.getDescricao_tarefa());
                return true;
            } else {
                System.out.println("Lista de tarefas não encontrada.");
                return false;
            }
        } catch (java.sql.SQLException e) {
            System.out.println("Erro ao pesquisar lista de tarefas: " + e.getMessage());
            return false;
        }
    }

    public boolean buscarResponsavel(Responsavel responsavel) {
        String sql = "SELECT * FROM responsavel WHERE id = ?";
        try (Connection conn = ConexaoBanco.getConnection();
             java.sql.PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, responsavel.getId());
            var rs = stmt.executeQuery();
            if (rs.next()) {
                responsavel.setNome(rs.getString("nome"));
                System.out.println("Responsável encontrado: " + responsavel.getNome());
                return true;
            } else {
                System.out.println("Responsável não encontrado.");
                return false;
            }
        } catch (java.sql.SQLException e) {
            System.out.println("Erro ao buscar responsável: " + e.getMessage());
            return false;
        }
    }

    public boolean buscarPrioridade(Prioridade prioridade) {
        String sql = "SELECT * FROM prioridade WHERE id = ?";
        try (Connection conn = ConexaoBanco.getConnection();
             java.sql.PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, prioridade.getId());
            var rs = stmt.executeQuery();
            if (rs.next()) {
                prioridade.setDescricao(rs.getString("descricao"));
                System.out.println("Prioridade encontrada: " + prioridade.getDescricao());
                return true;
            } else {
                System.out.println("Prioridade não encontrada.");
                return false;
            }
        } catch (java.sql.SQLException e) {
            System.out.println("Erro ao buscar prioridade: " + e.getMessage());
            return false;
        }
    }

}
