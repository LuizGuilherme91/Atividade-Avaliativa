import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Responsavel extends ClasseGenerica{
    private Integer id;
    private String nome;

    public Responsavel() {}
    public Responsavel(Integer id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public boolean salvarResponsavel(Responsavel responsavel) {
        String sql = "INSERT INTO responsavel (nome) VALUES (?)";
        try (Connection conn = ConexaoBanco.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, responsavel.getNome());
            stmt.executeUpdate();
            System.out.println("Responsável salvo com sucesso!");
            return true;
        } catch (SQLException e) {
            System.out.println("Erro ao salvar responsável: " + e.getMessage());
            return false;
        }
    }

    public boolean alterarResponsavel(Responsavel responsavel) {
        String sql = "UPDATE responsavel SET nome = ? WHERE id = ?";
        try (Connection conn = ConexaoBanco.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, responsavel.getNome());
            stmt.setInt(2, responsavel.getId());
            stmt.executeUpdate();
            System.out.println("Responsável alterado com sucesso!");
            return true;
        } catch (SQLException e) {
            System.out.println("Erro ao alterar responsável: " + e.getMessage());
            return false;
        }
    }

    public boolean deletarResponsavel(Responsavel responsavel) {
        String sql = "DELETE FROM responsavel WHERE id = ?";
        try (Connection conn = ConexaoBanco.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, responsavel.getId());
            stmt.executeUpdate();
            System.out.println("Responsável deletado com sucesso!");
            return true;
        } catch (SQLException e) {
            System.out.println("Erro ao deletar responsável: " + e.getMessage());
            return false;
        }
    }

    public boolean pesquisarResponsavel(Responsavel responsavel) {
        String sql = "SELECT * FROM responsavel WHERE id = ?";
        try (Connection conn = ConexaoBanco.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, responsavel.getId());
            var rs = stmt.executeQuery();
            if (rs.next()) {
                responsavel.setNome(rs.getString("nome"));
                System.out.println("Responsável encontrado: " + responsavel.getNome());
                return true;
            } else {
                System.out.println("Responsável não encontrado.");
                return false;
            }
        } catch (SQLException e) {
            System.out.println("Erro ao pesquisar responsável: " + e.getMessage());
            return false;
        }
    }
}
