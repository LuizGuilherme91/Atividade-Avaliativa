import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JPanel;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaPrioridade extends JFrame {

     private JPanel painelMenu;
    private JPanel painelConteudo;
    private CardLayout cardLayout;

    public TelaPrioridade() {
        setTitle("Gestão de Prioridades");
        setSize(500, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // ----- MENU -----
        painelMenu = new JPanel(new GridLayout(1, 4, 10, 10));
        JButton btnCadastrar = new JButton("Cadastrar");
        JButton btnAlterar = new JButton("Alterar");
        JButton btnDeletar = new JButton("Deletar");
        JButton btnPesquisar = new JButton("Pesquisar");

        painelMenu.add(btnCadastrar);
        painelMenu.add(btnAlterar);
        painelMenu.add(btnDeletar);
        painelMenu.add(btnPesquisar);

        add(painelMenu, BorderLayout.NORTH);

        // ----- CONTEÚDO -----
        cardLayout = new CardLayout();
        painelConteudo = new JPanel(cardLayout);

        painelConteudo.add(new PainelCadastrar(), "cadastrar");
        painelConteudo.add(new PainelAlterar(), "alterar");
        painelConteudo.add(new PainelDeletar(), "deletar");
        painelConteudo.add(new PainelPesquisar(), "pesquisar");

        add(painelConteudo, BorderLayout.CENTER);

        // ----- AÇÕES DO MENU -----
        btnCadastrar.addActionListener(e -> cardLayout.show(painelConteudo, "cadastrar"));
        btnAlterar.addActionListener(e -> cardLayout.show(painelConteudo, "alterar"));
        btnDeletar.addActionListener(e -> cardLayout.show(painelConteudo, "deletar"));
        btnPesquisar.addActionListener(e -> cardLayout.show(painelConteudo, "pesquisar"));

        setVisible(true);
    }

    // ===================== PAINÉIS =====================

    static class PainelCadastrar extends JPanel {
        public PainelCadastrar() {
            setLayout(new GridLayout(2,2,10,10));
            add(new JLabel("Descrição:"));
            JTextField txtDescricao = new JTextField();
            add(txtDescricao);

            JButton btnSalvar = new JButton("Salvar");
            add(btnSalvar);

            btnSalvar.addActionListener(e -> {
                String desc = txtDescricao.getText();
                if(desc.isEmpty()){
                    JOptionPane.showMessageDialog(this,"Informe a descrição!");
                } else {
                    JOptionPane.showMessageDialog(this,"Cadastrado: "+desc);
                    txtDescricao.setText("");
                }
            });
        }
    }

    static class PainelAlterar extends JPanel {
        public PainelAlterar() {
            setLayout(new GridLayout(3,2,10,10));
            add(new JLabel("Descrição antiga:"));
            JTextField txtAntiga = new JTextField();
            add(txtAntiga);

            add(new JLabel("Nova descrição:"));
            JTextField txtNova = new JTextField();
            add(txtNova);

            JButton btnAlterar = new JButton("Alterar");
            add(btnAlterar);

            btnAlterar.addActionListener(e -> {
                String antiga = txtAntiga.getText();
                String nova = txtNova.getText();
                if(antiga.isEmpty() || nova.isEmpty()){
                    JOptionPane.showMessageDialog(this,"Preencha todos os campos!");
                } else {
                    JOptionPane.showMessageDialog(this,"Alterado: "+antiga+" -> "+nova);
                    txtAntiga.setText(""); txtNova.setText("");
                }
            });
        }
    }

    static class PainelDeletar extends JPanel {
        public PainelDeletar() {
            setLayout(new GridLayout(2,2,10,10));
            add(new JLabel("Descrição a deletar:"));
            JTextField txtDescricao = new JTextField();
            add(txtDescricao);

            JButton btnDeletar = new JButton("Deletar");
            add(btnDeletar);

            btnDeletar.addActionListener(e -> {
                String desc = txtDescricao.getText();
                if(desc.isEmpty()){
                    JOptionPane.showMessageDialog(this,"Informe a descrição!");
                } else {
                    JOptionPane.showMessageDialog(this,"Deletado: "+desc);
                    txtDescricao.setText("");
                }
            });
        }
    }

    static class PainelPesquisar extends JPanel {
        public PainelPesquisar() {
            setLayout(new GridLayout(2,2,10,10));
            add(new JLabel("Descrição a pesquisar:"));
            JTextField txtDescricao = new JTextField();
            add(txtDescricao);

            JButton btnPesquisar = new JButton("Pesquisar");
            add(btnPesquisar);

            btnPesquisar.addActionListener(e -> {
                String desc = txtDescricao.getText();
                if(desc.isEmpty()){
                    JOptionPane.showMessageDialog(this,"Informe a descrição!");
                } else {
                    JOptionPane.showMessageDialog(this,"Resultado da pesquisa para: "+desc);
                    txtDescricao.setText("");
                }
            });
        }
    }
}