public class ClasseGenerica {
    private Integer id;


    public ClasseGenerica() {}

    public ClasseGenerica(Integer id) {
        this.id = id;
    }

    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

}
